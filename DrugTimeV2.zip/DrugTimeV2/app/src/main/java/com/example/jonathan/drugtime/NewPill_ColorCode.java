package com.example.jonathan.drugtime;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.graphics.drawable.GradientDrawable;

import static com.example.jonathan.drugtime.R.id.black;


public class NewPill_ColorCode extends AppCompatActivity {
    private Pill pill;
    String colorcode;
    private Bundle b;

    @Override
    protected  void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.newpillcolorcode_layout);

        final TextView farve = (TextView) findViewById(R.id.tv_farve);

        //Intent intent = getIntent();
        //pill = (Pill)intent.getSerializableExtra("newPill");
        b = getIntent().getExtras();
        pill = b.getParcelable("newPill");

        String pill_colorcode = "";
        if (pill != null) {
            pill_colorcode = pill.getColorCode();
        }

        if (pill_colorcode.equals("Red")) {
            farve.setBackgroundColor(Color.RED);
        } else if (pill_colorcode.equals("Blue")) {
            farve.setBackgroundColor(Color.BLUE);
        } else if (pill_colorcode.equals("Green")) {
            farve.setBackgroundColor(Color.GREEN);
        } else if (pill_colorcode.equals("Yellow")) {
            farve.setBackgroundColor(Color.YELLOW);
        } else if (pill_colorcode.equals("Black")) {
            farve.setBackgroundColor(Color.BLACK);
        } else if (pill_colorcode.equals("Magenta")) {
            farve.setBackgroundColor(Color.MAGENTA);
        } else if (pill_colorcode.equals("Cyan")) {
            farve.setBackgroundColor(Color.CYAN);
        } else if (pill_colorcode.equals("White")) {
            farve.setBackgroundColor(Color.WHITE);
        }
        colorcode = pill_colorcode;

        Button btBack=(Button)findViewById(R.id.tilforrigeside);
        btBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View V) {
                Intent backIntent =  new Intent(NewPill_ColorCode.this,NewPill_Picture.class);
                backIntent.putExtra("newPill", pill);
                backIntent.putExtras(b);
                startActivity(backIntent);
            }
        });

        Button btNext=(Button)findViewById(R.id.tilnæsteside);
        btNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View V) {


                pill.setColorCode(colorcode);
                Intent intent = new Intent(NewPill_ColorCode.this, NewPill_TakeWith.class);
                intent.putExtra("newPill", pill);
                intent.putExtras(b);
                startActivity(intent);

            }
        });



        Button btRed=(Button)findViewById(R.id.red);
        btRed.setBackgroundColor(Color.RED);
        btRed.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View V) {
                farve.setBackgroundColor(Color.RED);
                colorcode = "Red";
            }
        });

        Button btBlue=(Button)findViewById(R.id.blue);
        btBlue.setBackgroundColor(Color.BLUE);
        btBlue.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View V) {
                farve.setBackgroundColor(Color.BLUE);
                colorcode = "Blue";
            }
        });

        Button btBlack=(Button)findViewById(black);
        btBlack.setBackgroundColor(Color.BLACK);
        btBlack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View V) {
                farve.setBackgroundColor(Color.BLACK);
                colorcode = "Black";
            }
        });

        Button btGreen=(Button)findViewById(R.id.green);
        btGreen.setBackgroundColor(Color.GREEN);
        btGreen.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View V) {
                farve.setBackgroundColor(Color.GREEN);
                colorcode = "Green";
            }
        });



        Button btWhite=(Button)findViewById(R.id.white);
        btWhite.setBackgroundColor(Color.WHITE);
        btWhite.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View V) {
                farve.setBackgroundColor(Color.WHITE);
                colorcode = "White";
            }
        });

        Button btYellow=(Button)findViewById(R.id.yellow);
        btYellow.setBackgroundColor(Color.YELLOW);
        btYellow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View V) {
                farve.setBackgroundColor(Color.YELLOW);
                colorcode = "Yellow";
            }
        });

        Button btMagenta=(Button)findViewById(R.id.magenta);
        btMagenta.setBackgroundColor(Color.MAGENTA);
        btMagenta.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View V) {
                farve.setBackgroundColor(Color.MAGENTA);
                colorcode = "Magenta";
            }
        });

        Button btCyan=(Button)findViewById(R.id.cyan);
        btCyan.setBackgroundColor(Color.CYAN);
        btCyan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View V) {
                farve.setBackgroundColor(Color.CYAN);
                colorcode = "Cyan";
            }
        });

    }

    @Override
    public void onBackPressed() {
        Intent backIntent= new Intent(NewPill_ColorCode.this, NewPill_Picture.class);
        backIntent.putExtra("newPill", pill);
        backIntent.putExtras(b);
        startActivity(backIntent);
    }

}







