package com.example.jonathan.drugtime;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;


public class NewPill_Name extends AppCompatActivity {
    private EditText pillname;
    private Pill pill;
    private Button btNext;
    private int id;

    @Override
    protected  void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.newpillname_layout);
        Bundle b = getIntent().getExtras();
        id = b.getInt("id");

        if (id == 0 || id == 50) {
            id = 1;
        } else {
            id += 1;
        }

        btNext=(Button)findViewById(R.id.tilnæsteside);

        btNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View V) {
                if (pill == null) {
                    pill = new Pill();
                    pill.setId(id);
                }
                String newItem = pillname.getText().toString();

                pill.setName(newItem);


                Intent intent = new Intent(NewPill_Name.this, NewPill_Quantity.class);
                Bundle bundle = new Bundle();
                bundle.putInt("id", id);
                intent.putExtra("newPill", pill);
                intent.putExtras(bundle);
                startActivity(intent);

            }
        });

        pillname = (EditText) findViewById(R.id.pillname);
        if (pillname.getText().toString().length() == 0) {
            btNext.setEnabled(false);
        } else {
            btNext.setEnabled(true);
        }

        pillname.addTextChangedListener(new TextWatcher() {

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

                if(s.toString().trim().length()==0){
                    btNext.setEnabled(false);
                } else {
                    btNext.setEnabled(true);
                }
            }

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count,
                                          int after) {
                // TODO Auto-generated method stub

            }

            @Override
            public void afterTextChanged(Editable s) {
                // TODO Auto-generated method stub

            }
        });

        if (b != null) {
            pill = b.getParcelable("newPill");
            if (pill != null) {
                pillname.setText(pill.getName());
            }
        }

        Button btToMain=(Button)findViewById(R.id.tilstartside);
        btToMain.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View V) {
                Intent openMainActivity= new Intent(NewPill_Name.this, MainActivity.class);
                openMainActivity.setFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                startActivityIfNeeded(openMainActivity, 0);
            }
        });
    }

    @Override
    public void onBackPressed() {
        Intent openMainActivity= new Intent(NewPill_Name.this, MainActivity.class);
        openMainActivity.setFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
        startActivityIfNeeded(openMainActivity, 0);
    }

}

