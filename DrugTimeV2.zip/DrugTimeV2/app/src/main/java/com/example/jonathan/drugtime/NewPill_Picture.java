package com.example.jonathan.drugtime;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.media.Image;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

public class NewPill_Picture extends AppCompatActivity {
    private Pill pill;
    private Bundle b;
    private static final int CAMERA_REQUEST = 1888;
    ImageView cImageView;
    Bitmap photo;

    @Override
    protected  void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.newpillpicture_layout);


        //Intent intent = getIntent();
        //pill = (Pill)intent.getSerializableExtra("newPill");

        this.cImageView = (ImageView)findViewById(R.id.cameraImageView);

        b = getIntent().getExtras();
        pill = b.getParcelable("newPill");

        Bitmap.Config conf = Bitmap.Config.ARGB_8888; // see other conf types
        photo = Bitmap.createBitmap(200, 225, conf);
        cImageView.setImageBitmap(photo);

        Button btBack=(Button)findViewById(R.id.tilforrigeside);
        btBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View V) {
                Intent backIntent =  new Intent(NewPill_Picture.this,NewPill_Time.class);
                backIntent.putExtra("newPill", pill);
                backIntent.putExtras(b);
                startActivity(backIntent);
            }
        });

        Button btNext=(Button)findViewById(R.id.tilnæsteside);
        btNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View V) {

                Intent intent = new Intent(NewPill_Picture.this, NewPill_ColorCode.class);
                intent.putExtra("newPill", pill);
                intent.putExtras(b);
                startActivity(intent);

            }
        });

        Button photoButton = (Button) this.findViewById(R.id.take_pic_button);
        photoButton.setOnClickListener(new View.OnClickListener() {



            @Override
            public void onClick(View v) {
                Intent cameraIntent = new Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE);
                startActivityForResult(cameraIntent, CAMERA_REQUEST);
            }
        });

    }

    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == CAMERA_REQUEST && resultCode == Activity.RESULT_OK) {
            photo = (Bitmap) data.getExtras().get("data");
            pill.saveImage(this, photo, pill.getName(), "someInternalPath");
            cImageView.setImageBitmap(photo);
        }
    }

    @Override
    public void onBackPressed() {
        Intent backIntent= new Intent(NewPill_Picture.this, NewPill_Time.class);
        backIntent.putExtra("newPill", pill);
        backIntent.putExtras(b);
        startActivity(backIntent);
    }

}
