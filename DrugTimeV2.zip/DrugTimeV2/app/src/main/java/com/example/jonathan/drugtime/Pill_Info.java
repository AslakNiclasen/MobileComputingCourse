package com.example.jonathan.drugtime;

import android.app.AlarmManager;
import android.app.DialogFragment;
import android.app.PendingIntent;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;


public class Pill_Info extends AppCompatActivity {
    private Pill pill;
    private Pill oldPill;
    private TextView tv_tidspunkt;
    private TextView tv_pillenavn;
    private TextView tv_tagesmed;
    //private TextView tv_billede;
    private TextView farve, tv_quantity, tv_note;
    private Button btDelete, btUpdate, btNewTime, btCancel;
    private ImageView iv_image;
    private EditText et_navn;
    private int id;
    private int oldPill_id;


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.pillinfo_layout);




        //Intent intent = getIntent();
        //oldPill = (Pill)intent.getSerializableExtra("Pill");
        Bundle b = getIntent().getExtras();
        oldPill = b.getParcelable("Pill");
        oldPill_id = oldPill.getId();

        id = b.getInt("id");
        Bitmap image = oldPill.getImageBitmap(this, oldPill.getName(), "someInternalPath");
        pill = oldPill;

        tv_pillenavn = (TextView) findViewById(R.id.name);
        tv_tidspunkt = (TextView) findViewById(R.id.time);
        //tv_tagesmed = (TextView) findViewById(R.id.tv_tagesmed);
        //tv_billede = (TextView) findViewById(R.id.tv_billede);
        farve = (TextView) findViewById(R.id.farvekode);
        iv_image = (ImageView) findViewById(R.id.imageView);
        tv_quantity = (TextView) findViewById(R.id.quantity);
        tv_note = (TextView) findViewById(R.id.note);

        tv_tidspunkt.setText(oldPill.getTime());
        tv_pillenavn.setText(oldPill.getName());
        iv_image.setImageBitmap(image);
        tv_note.setText(oldPill.getNote());
        tv_quantity.setText(String.valueOf(oldPill.getQuantity()));

        String pill_colorcode = oldPill.getColorCode();

        if (pill_colorcode.equals("Red")) {
            farve.setBackgroundColor(Color.RED);
        } else if (pill_colorcode.equals("Blue")) {
            farve.setBackgroundColor(Color.BLUE);
        } else if (pill_colorcode.equals("Green")) {
            farve.setBackgroundColor(Color.GREEN);
        } else if (pill_colorcode.equals("Yellow")) {
            farve.setBackgroundColor(Color.YELLOW);
        } else if (pill_colorcode.equals("Black")) {
            farve.setBackgroundColor(Color.BLACK);
        } else if (pill_colorcode.equals("Magenta")) {
            farve.setBackgroundColor(Color.MAGENTA);
        } else if (pill_colorcode.equals("Cyan")) {
            farve.setBackgroundColor(Color.CYAN);
        } else if (pill_colorcode.equals("White")) {
            farve.setBackgroundColor(Color.WHITE);
        } else {
            farve.setText("Ingen");
        }
        //pillensnavn = (TextView) findViewById(R.id.pillensnavn);

        //et_navn = (EditText)findViewById(R.id.et_navn);
        //et_navn.setText(pill.getName());

        /*btNewTime=(Button)findViewById(R.id.bt_tidspunkt);
        btNewTime.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View V) {
                DialogFragment newFragment = new TimePickerFragment();
                newFragment.show(getFragmentManager(),"TimePicker");
            }
        });*/

        btDelete=(Button)findViewById(R.id.sletpille);
        btDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View V) {
                Intent myIntent = new Intent(Pill_Info.this, Notification_receiver.class);
                PendingIntent pendingIntent = PendingIntent.getActivity(Pill_Info.this,oldPill_id, myIntent,PendingIntent.FLAG_UPDATE_CURRENT);
                pendingIntent.cancel();
                AlarmManager alarmManager = (AlarmManager) getSystemService(ALARM_SERVICE);
                alarmManager.cancel(pendingIntent);

                Intent openMainActivity= new Intent(Pill_Info.this, MainActivity.class);
                openMainActivity.putExtra("deletePill", oldPill);
                openMainActivity.putExtra("id",id);
                openMainActivity.setFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                startActivityIfNeeded(openMainActivity, 0);
            }
        });

        btCancel=(Button)findViewById(R.id.tilbage);
        btCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View V) {
                Intent openMainActivity= new Intent(Pill_Info.this, MainActivity.class);
                openMainActivity.setFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                openMainActivity.putExtra("id",id);
                startActivityIfNeeded(openMainActivity, 0);
            }
        });


        /*
        btUpdate=(Button)findViewById(R.id.opdater);
        btUpdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View V) {
                //Intent intent = new Intent(Pill_Info.this, MainActivity.class);
                //intent.putExtra("newPill", pill);
                //startActivity(intent);


                //String newItem = tv_tidspunkt.getText().toString();
                //pill.setTime(newItem);
                String new_name = et_navn.getText().toString();
                pill.setName(new_name);

                String text = tv_tidspunkt.getText().toString();
                String parts[] = text.split(" ");
                String subbed = parts[parts.length - 1];
                pill.setTime(subbed);

                Intent openMainActivity= new Intent(Pill_Info.this, MainActivity.class);
                openMainActivity.putExtra("deletePill", oldPill);
                openMainActivity.putExtra("updatePill", pill);
                openMainActivity.putExtra("id",id);

                openMainActivity.setFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                startActivityIfNeeded(openMainActivity, 0);

                //Intent intent = new Intent(NewPill_Final.this, MainActivity.class);
                //intent.putExtra("newPill", pill);
                //startActivity(intent);

            }
        });*/

    }

    @Override
    public void onBackPressed() {
        Intent openMainActivity= new Intent(Pill_Info.this, MainActivity.class);
        openMainActivity.setFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
        openMainActivity.putExtra("id",id);
        startActivityIfNeeded(openMainActivity, 0);
    }


}

