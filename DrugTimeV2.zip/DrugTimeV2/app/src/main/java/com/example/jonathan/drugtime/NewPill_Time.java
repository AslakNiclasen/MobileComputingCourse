package com.example.jonathan.drugtime;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.app.DialogFragment;

public class NewPill_Time extends AppCompatActivity {
    private Pill pill;
    private Bundle b;
    private TextView valgttidspunkt;
    private Button btNext;

    @Override
    protected  void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.newpilltime_layout);

        //Intent intent = getIntent();
        //pill = (Pill)intent.getSerializableExtra("newPill");
        b = getIntent().getExtras();
        pill = b.getParcelable("newPill");

        valgttidspunkt = (TextView) findViewById(R.id.tv_tidspunkt);

        if (pill != null) {
            if (pill.getMinute() != -1) {
                valgttidspunkt.setText(pill.getTime());
            }
        }




        Button btBack=(Button)findViewById(R.id.tilforrigeside);
        btBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View V) {
                String time = valgttidspunkt.getText().toString();
                if (!time.equals("")) {
                    pill.setTime(time);
                }
                Intent backIntent = new Intent(NewPill_Time.this, NewPill_Quantity.class);
                backIntent.putExtra("newPill", pill);
                backIntent.putExtras(b);
                startActivity(backIntent);
            }
        });


        btNext=(Button)findViewById(R.id.tilnæsteside);
        btNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View V) {
                String time = valgttidspunkt.getText().toString();
                pill.setTime(time);
                Intent intent = new Intent(NewPill_Time.this, NewPill_Picture.class);
                intent.putExtra("newPill", pill);
                intent.putExtras(b);
                startActivity(intent);

            }
        });

        if (valgttidspunkt.getText().toString().length() == 0) {
            btNext.setEnabled(false);
        } else {
            btNext.setEnabled(true);
        }



        Button btTime=(Button)findViewById(R.id.vælgtidspunkt);
        btTime.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View V) {

                DialogFragment newFragment = new TimePickerFragment();
                newFragment.show(getFragmentManager(),"TimePicker");
            }
        });

        valgttidspunkt.addTextChangedListener(new TextWatcher() {

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

                if(s.toString().trim().length()==0){
                    btNext.setEnabled(false);
                } else {
                    btNext.setEnabled(true);
                }


            }

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count,
                                          int after) {
                // TODO Auto-generated method stub

            }

            @Override
            public void afterTextChanged(Editable s) {
                // TODO Auto-generated method stub

            }
        });
    }

    @Override
    public void onBackPressed() {
        String time = valgttidspunkt.getText().toString();
        if (!time.equals("")) {
            pill.setTime(time);
        }
        Intent backIntent = new Intent(NewPill_Time.this, NewPill_Quantity.class);
        backIntent.putExtra("newPill", pill);
        backIntent.putExtras(b);
        startActivity(backIntent);
    }


}

