package com.example.jonathan.drugtime;

import android.graphics.Color;
import android.os.Bundle;
import android.support.v4.view.GravityCompat;
import android.view.View;
import android.support.design.widget.NavigationView;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.util.Log;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.AdapterView.OnItemClickListener;
import android.content.Intent;
import java.lang.reflect.Type;
import java.util.ArrayList;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import android.support.annotation.NonNull;

import org.w3c.dom.Text;

public class MainActivity extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener, OnItemClickListener {

    private ArrayList<Pill> pillList;

    private PillAdapter my_adapter;
    private int id;
    private ListView listview;
    private SharedPreferences mPrefs;
    private Bundle b;
    private TextView line1;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        b = getIntent().getExtras();

        if (b != null) {
            if (b.containsKey("id")) {
                id = b.getInt("id");
            }
        } else {
            id = 8;
        }

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);





        pillList = new ArrayList<>();
        my_adapter = new PillAdapter(this, pillList);
        listview = (ListView) findViewById(R.id.thelist);
        listview.setOnItemClickListener(new ListClickHandler());
        listview.setAdapter(my_adapter);

        /*
        Pill samplePill = new Pill();
        samplePill.setName("Denne pille er et eksempel");
        pillList.add(samplePill);
        my_adapter.notifyDataSetChanged();
        */

        /*
        txtInput = (EditText) findViewById(R.id.txtinput);

        Button btAdd=(Button)findViewById(R.id.btadd);
        btAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View V) {
                String newItem = txtInput.getText().toString();
                Pill pill = new Pill();
                pill.setName(newItem);
                pillList.add(pill);

                my_adapter.notifyDataSetChanged();
            }
        });

        Button btAlarm=(Button)findViewById(R.id.btAlarm);
        btAlarm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View V) {
                Calendar calendar = Calendar.getInstance();


                String newItem = txtInput.getText().toString();

                String[] parts = newItem.split(":");

                int hour = Integer.parseInt(parts[0]);
                int minute = Integer.parseInt(parts[1]);

                my_adapter.notifyDataSetChanged();

                calendar.set(Calendar.HOUR_OF_DAY,hour);
                calendar.set(Calendar.MINUTE, minute);

                Intent intent = new Intent(getApplicationContext(),Notification_receiver.class);

                PendingIntent pendingIntent = PendingIntent.getBroadcast(getApplicationContext(),100,intent,PendingIntent.FLAG_UPDATE_CURRENT);

                AlarmManager alarmManager = (AlarmManager) getSystemService(ALARM_SERVICE);
                alarmManager.setRepeating(AlarmManager.RTC_WAKEUP, calendar.getTimeInMillis(),AlarmManager.INTERVAL_DAY,pendingIntent);


            }
        });*/

    }





    @Override
    public void onPause() {
        super.onPause();

        mPrefs = getPreferences(MODE_PRIVATE);
        //SharedPreferences.Editor editor = mPrefs.edit();

        Editor prefsEditor = mPrefs.edit();
        Gson gson = new Gson();

        String json_id = gson.toJson(id);
        //String json_names = gson.toJson(nameList);
        //String json_times = gson.toJson(timeList);
        //prefsEditor.putString("ListOfPillNames", json_names);
        //prefsEditor.putString("ListOfPillTimes", json_times);
        String json_pills = gson.toJson(pillList);
        prefsEditor.putString("ListOfPills", json_pills);
        prefsEditor.putString("id", json_id);
        prefsEditor.apply();

        //editor.putInt("thelist", arrayList);
        //editor.commit();
    }

    @Override
    public void onResume() {
        super.onResume();

        mPrefs = getPreferences(MODE_PRIVATE);

        String json_pills = mPrefs.getString("ListOfPills", "");
        //txtInput = (EditText) findViewById(R.id.txtinput);
        //txtInput.setText(String.valueOf(json_pills.length()));


        String json_id = mPrefs.getString("id", "");
        if (mPrefs.contains("id")) {
            id = new Gson().fromJson(json_id, int.class);
        }

        Type listType = new TypeToken<ArrayList<Pill>>() {}.getType();

        if (json_pills.length() > 10) {
            pillList = new Gson().fromJson(json_pills, listType);

        } else {
            pillList = new ArrayList<>();
        }


        b = getIntent().getExtras();
        Pill newPill;


        if (b != null) {
            if (b.containsKey("id")) {
                id = b.getInt("id");
            }
        } else {
            b = new Bundle();
        }

        if (id == 0) {
            id = 1;
        }
        b.putInt("id", id);


        if ((getIntent().getParcelableExtra("newPill")) != null) {
            newPill = b.getParcelable("newPill");
            pillList.add(newPill);
        }

        //Pill newPill = b.getParcelable("newPill");
        Pill deletePill; // = b.getParcelable("deletePill");
        if ((getIntent().getParcelableExtra("deletePill")) != null) {
            deletePill = b.getParcelable("deletePill");
            Pill pill;
            int delete_id = deletePill.getId();
            for (int i = 0; i < pillList.size(); i++) {
                pill = pillList.get(i);
                if (pill.getId() == delete_id) {
                    pillList.remove(i);
                    break;
                }
            }
        }

        Pill updatePill; // This functionality was removed for simplicity
        if ((getIntent().getParcelableExtra("updatePill")) != null) {
            updatePill = b.getParcelable("updatePill");
            pillList.add(updatePill);
        }

        listview = (ListView) findViewById(R.id.thelist);
        listview.setOnItemClickListener(new ListClickHandler());

        int listBlue = getResources().getColor(R.color.listBlue);
        listview.setBackgroundColor(listBlue);

        int size = pillList.size();
        for (int i = 0; i<size; i++) {
            int pill_id = pillList.get(i).getId();
            for (int j = i+1; j < size; j++) {
                int pill_id2 = pillList.get(j).getId();
                if (pill_id == pill_id2) {
                    pillList.remove(j);
                    size = pillList.size();
                }
            }
        }

        my_adapter = new PillAdapter(this, pillList);
        listview.setAdapter(my_adapter);
        my_adapter.notifyDataSetChanged();

        line1 = (TextView)findViewById(R.id.line1);
        line1.setText("Tryk på menuen oppe til venstre.");
        line1.setTextSize(18f);
    }

    @Override
    protected void onNewIntent(Intent intent) {
        if (intent != null)
            setIntent(intent);
    }

    @Override
    public void onBackPressed() {
        // We disable back button on main activity
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.action_settings) {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        int item_id = item.getItemId();

        if (item_id == R.id.opret_ny_pille) {
            Intent newPillIntent = new Intent(this, NewPill_Name.class);
            newPillIntent.putExtra("id", id);
            startActivity(newPillIntent);
        } else if (item_id == R.id.slet_en_pille) {
            line1.setText("Tryk på den pille du vil slette.");
            line1.setTextSize(24f);
        //} else if (item_id == R.id.rediger_en_pille) {
        //    line1.setText("Tryk på den pille du vil ændre.");
        //    line1.setTextSize(24f);
        } else if (item_id == R.id.luk_menu) {
            line1.setText("Tryk på menuen oppe til venstre.");
            line1.setTextSize(18f);
        } else if (item_id == R.id.luk_program) {
            finish();
            System.exit(0);
        }

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

    public void onItemClick(AdapterView<?> l, View v, int position, long id) {}

    private class ListClickHandler implements OnItemClickListener{

        @Override
        public void onItemClick(AdapterView<?> av, View view, int position, long arg3) {
            TextView listText_name = (TextView) view.findViewById(R.id.pillenavn);
            String text = listText_name.getText().toString();

            Pill pill = new Pill();
            for (int i = 0; i < pillList.size(); i++) {
                pill = pillList.get(i);
                if (pill.getName().equals(text)) {
                    break;
                }
            }

            Intent intent = new Intent(MainActivity.this, Pill_Info.class);
            intent.putExtra("id", id);
            intent.putExtra("Pill", pill);
            startActivity(intent);
        }
    }


}






