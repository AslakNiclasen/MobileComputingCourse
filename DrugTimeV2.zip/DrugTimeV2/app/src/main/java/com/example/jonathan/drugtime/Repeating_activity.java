package com.example.jonathan.drugtime;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.support.annotation.Nullable;
import android.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.Calendar;

public class Repeating_activity extends AppCompatActivity {
    Bundle bundle;
    Button btTakePill;
    Button btSnooze;
    private AlertDialog.Builder builderTagPille;
    private AlertDialog.Builder builderUdsæt;
    String name, time, pill_colorcode, noten;
    int quantity, id, hour, minute;
    Calendar calendar;

    @Override
    protected  void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.repeating_activity_layout);


        bundle = getIntent().getExtras();
        name = bundle.getString("name");
        time = bundle.getString("time");
        quantity = bundle.getInt("quantity");
        pill_colorcode = bundle.getString("color_code");
        noten = bundle.getString("note");
        id = bundle.getInt("id");
        Bitmap image = (new Pill()).getImageBitmap(this, name, "someInternalPath");

        makeInstantAlarmToKeepNotification();

        TextView pillensnavn = (TextView) findViewById(R.id.name);
        TextView tidspunkt = (TextView) findViewById(R.id.time);
        TextView antal = (TextView) findViewById(R.id.quantity);
        TextView farve = (TextView) findViewById(R.id.farvekode);
        TextView note = (TextView) findViewById(R.id.note);
        ImageView imageView = (ImageView) findViewById(R.id.imageView);

        imageView.setImageBitmap(image);

        pillensnavn.setText(name);
        tidspunkt.setText(time);
        antal.setText(String.valueOf(quantity));
        note.setText(noten);
        if (pill_colorcode.equals("Red")) {
            farve.setBackgroundColor(Color.RED);
        } else if (pill_colorcode.equals("Blue")) {
            farve.setBackgroundColor(Color.BLUE);
        } else if (pill_colorcode.equals("Green")) {
            farve.setBackgroundColor(Color.GREEN);
        } else if (pill_colorcode.equals("Yellow")) {
            farve.setBackgroundColor(Color.YELLOW);
        } else if (pill_colorcode.equals("Black")) {
            farve.setBackgroundColor(Color.BLACK);
        } else if (pill_colorcode.equals("Magenta")) {
            farve.setBackgroundColor(Color.MAGENTA);
        } else if (pill_colorcode.equals("Cyan")) {
            farve.setBackgroundColor(Color.CYAN);
        } else if (pill_colorcode.equals("White")) {
            farve.setBackgroundColor(Color.WHITE);
        } else {
            farve.setText("Ingen");
        }

        btTakePill=(Button)findViewById(R.id.tagpille);
        btTakePill.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View V) {
                builderTagPille = new AlertDialog.Builder(Repeating_activity.this);
                builderTagPille.setTitle("Bekræft");
                builderTagPille.setMessage("Har du taget din(e) pille(r)?");
                builderTagPille.setPositiveButton("Ja", new DialogInterface.OnClickListener() {

                    public void onClick(DialogInterface dialog, int which) {
                        endNotification();
                        makeNextAlarm();
                        toMainActivity();

                        dialog.dismiss();
                    }
                });
                builderTagPille.setNegativeButton("Nej", new DialogInterface.OnClickListener() {

                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                        dialog.dismiss();
                    }
                });
                builderTagPille.show();
            }
        });

        btSnooze=(Button)findViewById(R.id.udsæt);
        btSnooze.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View V) {
                builderUdsæt = new AlertDialog.Builder(Repeating_activity.this);
                builderUdsæt.setTitle("Udsæt alarmen");
                builderUdsæt.setMessage("Hvor længe vil du udsætte alarmen?");
                builderUdsæt.setPositiveButton("1 time", new DialogInterface.OnClickListener() {

                    public void onClick(DialogInterface dialog, int which) {
                        endNotification();
                        WakeLocker.release();
                        udsætAlarm(1);
                        dialog.dismiss();
                        toMainActivity();
                    }
                });
                builderUdsæt.setNegativeButton("10 minutter", new DialogInterface.OnClickListener() {

                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        endNotification();
                        WakeLocker.release();
                        udsætAlarm(10);
                        dialog.dismiss();
                        toMainActivity();
                    }
                });
                builderUdsæt.setNeutralButton("Tilbage", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        WakeLocker.release();
                        dialog.dismiss();
                    }
                });
                builderUdsæt.show();
            }
        });
    }

    public void toMainActivity() {
        Intent openMainActivity = new Intent(Repeating_activity.this, MainActivity.class);
        openMainActivity.putExtras(bundle);
        openMainActivity.setFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
        startActivityIfNeeded(openMainActivity, 0);
    }

    public void udsætAlarm(int tid) {
        calendar = Calendar.getInstance();

        hour = calendar.get(Calendar.HOUR);
        minute = calendar.get(Calendar.MINUTE);

        int new_hour = hour;
        int new_minute = minute;

        if (tid == 10) {
            if (minute >= 50) {
                new_minute = minute % 50;
                if (hour == 23) {
                    new_hour = 0;
                } else {
                    new_hour += 1;
                }
            } else {
                new_minute = minute + tid;
            }
        } else {
            if (hour == 23) {
                new_hour = 0;
            } else {
                new_hour += 1;
            }
        }

        calendar.set(Calendar.HOUR_OF_DAY,new_hour);
        calendar.set(Calendar.MINUTE, new_minute);

        Intent notificationReceiverActivity = new Intent(Repeating_activity.this,Notification_receiver.class);
        Bundle bundle = new Bundle();


        bundle.putString("name", name);
        bundle.putInt("quantity", quantity);
        bundle.putString("color_code", pill_colorcode);
        bundle.putString("time", time);
        bundle.putString("note", noten);
        bundle.putInt("id", id);
        bundle.putInt("vibrate", 1);
        notificationReceiverActivity.putExtras(bundle);

        PendingIntent pendingIntent = PendingIntent.getBroadcast(getApplicationContext(),id,notificationReceiverActivity,PendingIntent.FLAG_UPDATE_CURRENT);

        AlarmManager alarmManager = (AlarmManager) getSystemService(ALARM_SERVICE);
        alarmManager.set(AlarmManager.RTC_WAKEUP, calendar.getTimeInMillis(),pendingIntent);

    }

    @Override
    public void onBackPressed() {

    }

    public void endNotification() {
        NotificationManager notificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        notificationManager.cancel(id);
    }

    public void makeInstantAlarmToKeepNotification() {
        Intent notificationReceiverActivity = new Intent(Repeating_activity.this,Notification_receiver.class);

        bundle.putInt("vibrate", 0);
        notificationReceiverActivity.putExtras(bundle);

        PendingIntent pendingIntent = PendingIntent.getBroadcast(getApplicationContext(),id,notificationReceiverActivity,PendingIntent.FLAG_UPDATE_CURRENT);

        AlarmManager alarmManager = (AlarmManager) getSystemService(ALARM_SERVICE);
        alarmManager.set(AlarmManager.ELAPSED_REALTIME_WAKEUP, 0,pendingIntent);

    }

    public void makeNextAlarm() {
        Intent notificationReceiverActivity = new Intent(Repeating_activity.this,Notification_receiver.class);

        calendar = Calendar.getInstance();

        int day = calendar.get(Calendar.DAY_OF_MONTH);

        calendar.set(Calendar.DAY_OF_MONTH, day+1);
        calendar.set(Calendar.HOUR_OF_DAY,hour);
        calendar.set(Calendar.MINUTE, minute);

        bundle.putInt("vibrate", 1);
        notificationReceiverActivity.putExtras(bundle);

        PendingIntent pendingIntent = PendingIntent.getBroadcast(getApplicationContext(),id,notificationReceiverActivity,PendingIntent.FLAG_UPDATE_CURRENT);

        AlarmManager alarmManager = (AlarmManager) getSystemService(ALARM_SERVICE);
        alarmManager.set(AlarmManager.RTC_WAKEUP, calendar.getTimeInMillis(),pendingIntent);

    }
}



