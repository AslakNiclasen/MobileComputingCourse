package com.example.jonathan.drugtime;

/**
 * Created by Jonathan on 15-05-2017.
 */

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.Rect;
import android.graphics.RectF;
import android.os.Parcelable;

import android.os.Parcel;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.Serializable;

public class Pill implements Parcelable {
    private String name;
    private String color_code;
    //private boolean daily;
    private int hour;
    private int minute;
    private String time;
    private int quantity;
    private String note;
    private int id;
    private transient Bitmap cImage;

    public Pill() {
        this.name = "";
        this.color_code = "";
        //this.daily = false;
        this.hour = -1;
        this.minute = -1;
        this.time = "";
        this.quantity = 1;
        this.note = "";
        this.id = 0;
        this.cImage = null;
    }

    public void setId(int id) { this.id = id;}
    public int getId() {return this.id;}
    public void setName(String pill_name) {
        this.name = pill_name;
    }

    public String getName() {
        return this.name;
    }

    public void setQuantity(int quantity) { this.quantity = quantity; }

    public int getQuantity() { return this.quantity; }

    public int getHour() {
        return this.hour;
    }

    public int getMinute() {
        return this.minute;
    }

    public void setTime(String time) {
        if (time.length() <= 5) {
            String[] parts = time.split(":");
            this.hour = Integer.parseInt(parts[0]);
            this.minute = Integer.parseInt(parts[1]);
        } else {
            this.time = "Tidspunkt for alarm endnu ikke specificeret.";
        }
    }

    public String getTime() {
        String minuteText = "";
        if (minute < 10) {
            minuteText = "0" + String.valueOf(minute);
        } else {
            minuteText = String.valueOf(minute);
        }
        return (String.valueOf(hour) + ":" + minuteText);
    }

    public String getColorCode() {
        return color_code;
    }

    public void setColorCode(String color) {
        this.color_code = color;
    }

    public void setNote(String note) { this.note = note; }

    public String getNote() {return this.note; }

    public void saveImage(Context context, Bitmap b,String name,String extension){
        name=name+"."+extension;
        FileOutputStream out;
        Bitmap rounded_b = getRoundedCornerBitmap(b);
        try {
            out = context.openFileOutput(name, Context.MODE_PRIVATE);
            rounded_b.compress(Bitmap.CompressFormat.JPEG, 90, out);
            out.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static Bitmap getRoundedCornerBitmap(Bitmap bitmap) {
        Bitmap output = Bitmap.createBitmap(bitmap.getWidth(),
                bitmap.getHeight(), Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(output);

        final int color = 0xff424242;
        final Paint paint = new Paint();
        final Rect rect = new Rect(0, 0, bitmap.getWidth(), bitmap.getHeight());
        final RectF rectF = new RectF(rect);
        final float roundPx = 12;

        paint.setAntiAlias(true);
        canvas.drawARGB(0, 0, 0, 0);
        paint.setColor(color);
        canvas.drawRoundRect(rectF, roundPx, roundPx, paint);

        paint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.SRC_IN));
        canvas.drawBitmap(bitmap, rect, rect, paint);

        return output;
    }

    public Bitmap getImageBitmap(Context context,String name,String extension){
        name=name+"."+extension;
        try{
            FileInputStream fis = context.openFileInput(name);
            Bitmap b = BitmapFactory.decodeStream(fis);
            fis.close();
            return b;
        }
        catch(Exception e){
        }
        return null;
    }

            /**
             *
             * Constructor to use when re-constructing object
             * from a parcel
             *
             * @param in a parcel from which to read this object
             */
    public Pill(Parcel in) {
        readFromParcel(in);
    }


    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {

        // We just need to write each field into the
        // parcel. When we read from parcel, they
        // will come back in the same order
        dest.writeString(name);
        dest.writeString(color_code);
        //dest.writeByte((byte) (daily  ? 1 : 0));
        dest.writeInt(hour);
        dest.writeInt(minute);
        //dest.writeString(take_with);
        dest.writeString(time);
        dest.writeInt(quantity);
        dest.writeString(note);
        dest.writeInt(id);

    }

    /**
     *
     * Called from the constructor to create this
     * object from a parcel.
     *
     * @param in parcel from which to re-create object
     */
    private void readFromParcel(Parcel in) {

        // We just need to read back each
        // field in the order that it was
        // written to the parcel
        name = in.readString();
        color_code = in.readString();
        //daily = in.readByte() != 0;
        hour = in.readInt();
        minute = in.readInt();
        //take_with = in.readString();
        time = in.readString();
        quantity = in.readInt();
        note = in.readString();
        id = in.readInt();

    }

    /**
     *
     * This field is needed for Android to be able to
     * create new objects, individually or as arrays.
     *
     * This also means that you can use use the default
     * constructor to create the object and use another
     * method to hyrdate it as necessary.
     *
     * I just find it easier to use the constructor.
     * It makes sense for the way my brain thinks ;-)
     *
     */
    public static final Parcelable.Creator CREATOR =
            new Parcelable.Creator() {
                public Pill createFromParcel(Parcel in) {
                    return new Pill(in);
                }

                public Pill[] newArray(int size) {
                    return new Pill[size];
                }
            };
}
