package com.example.jonathan.drugtime;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;


public class NewPill_Quantity extends AppCompatActivity {
    private Pill pill;
    private Button btNext;
    private int quantity;
    private Bundle b;

    @Override
    protected  void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.newpillquantity_layout);

        btNext=(Button)findViewById(R.id.tilnæsteside);





        //Intent intent = getIntent();
        //pill = (Pill)intent.getSerializableExtra("newPill");
        b = getIntent().getExtras();
        pill = b.getParcelable("newPill");

        pill.setQuantity(1);
        quantity = pill.getQuantity();

        if (quantity == 0) {
            btNext.setEnabled(false);
        } else {
            btNext.setEnabled(true);
        }

        btNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View V) {
                Intent intent = new Intent(NewPill_Quantity.this, NewPill_Time.class);
                intent.putExtra("newPill", pill);
                intent.putExtras(b);
                startActivity(intent);

            }
        });

        Button btBack=(Button)findViewById(R.id.tilforrigeside);
        btBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View V) {
                Intent backIntent= new Intent(NewPill_Quantity.this, NewPill_Name.class);
                backIntent.putExtra("newPill", pill);
                backIntent.putExtras(b);
                startActivity(backIntent);
            }
        });

        Spinner spinner = (Spinner) findViewById(R.id.spinner);
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id)
            {
                String selectedItem = parent.getItemAtPosition(position).toString(); //this is your selected item
                quantity = Integer.parseInt(selectedItem);
                pill.setQuantity(quantity);
                btNext.setEnabled(true);

            }
            public void onNothingSelected(AdapterView<?> parent)
            {
                btNext.setEnabled(false);
            }
        });

        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.quantity, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);



    }

    @Override
    public void onBackPressed() {
        Intent backIntent= new Intent(NewPill_Quantity.this, NewPill_Name.class);
        backIntent.putExtra("newPill", pill);
        backIntent.putExtras(b);
        startActivity(backIntent);
    }

}

