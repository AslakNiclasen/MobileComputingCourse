package com.example.jonathan.drugtime;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.Calendar;

public class NewPill_Final extends AppCompatActivity {
    private Pill pill;
    private int id;
    private Bundle b;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.newpillfinal_layout);

        b = getIntent().getExtras();
        pill = b.getParcelable("newPill");
        id = b.getInt("id");

        Bitmap image = pill.getImageBitmap(this, pill.getName(), "someInternalPath");


        String name = pill.getName();
        String time = pill.getTime();
        String noten = pill.getNote();
        String quantity = String.valueOf(pill.getQuantity());

        ImageView pillebillede = (ImageView) findViewById(R.id.pillebillede);
        TextView pillensnavn = (TextView) findViewById(R.id.name);
        TextView tidspunkt = (TextView) findViewById(R.id.time);
        TextView antal = (TextView) findViewById(R.id.quantity);
        TextView farve = (TextView) findViewById(R.id.farvekode);
        TextView note = (TextView) findViewById(R.id.the_note);

        pillebillede.setImageBitmap(image);
        pillensnavn.setText(name);
        tidspunkt.setText(time);
        antal.setText(quantity);
        note.setText(noten);

        String pill_colorcode = pill.getColorCode();
        if (pill_colorcode.equals("Red")) {
            farve.setBackgroundColor(Color.RED);
        } else if (pill_colorcode.equals("Blue")) {
            farve.setBackgroundColor(Color.BLUE);
        } else if (pill_colorcode.equals("Green")) {
            farve.setBackgroundColor(Color.GREEN);
        } else if (pill_colorcode.equals("Yellow")) {
            farve.setBackgroundColor(Color.YELLOW);
        } else if (pill_colorcode.equals("Black")) {
            farve.setBackgroundColor(Color.BLACK);
        } else if (pill_colorcode.equals("Magenta")) {
            farve.setBackgroundColor(Color.MAGENTA);
        } else if (pill_colorcode.equals("Cyan")) {
            farve.setBackgroundColor(Color.CYAN);
        } else if (pill_colorcode.equals("White")) {
            farve.setBackgroundColor(Color.WHITE);
        } else {
            farve.setText("Ingen");
        }


        Button btBack=(Button)findViewById(R.id.tilforrigeside);
        btBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View V) {
                Intent intent = new Intent(NewPill_Final.this, NewPill_TakeWith.class);
                intent.putExtra("newPill", pill);
                intent.putExtras(b);
                startActivity(intent);
            }
        });


        Button btAddPill=(Button)findViewById(R.id.tilføjpille);
        btAddPill.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View V) {

                Calendar calendar = Calendar.getInstance();

                int hour = pill.getHour();
                int minute = pill.getMinute();

                calendar.set(Calendar.HOUR_OF_DAY,hour);
                calendar.set(Calendar.MINUTE, minute);

                Intent notificationReceiverActivity = new Intent(NewPill_Final.this,Notification_receiver.class);
                Bundle bundle = new Bundle();

                bundle.putString("name", pill.getName());
                bundle.putInt("quantity", pill.getQuantity());
                bundle.putString("color_code", pill.getColorCode());
                bundle.putString("time", pill.getTime());
                bundle.putString("note", pill.getNote());
                bundle.putInt("id", id);
                bundle.putInt("vibrate", 1);
                notificationReceiverActivity.putExtras(bundle);

                PendingIntent pendingIntent = PendingIntent.getBroadcast(getApplicationContext(),id,notificationReceiverActivity,PendingIntent.FLAG_UPDATE_CURRENT);

                AlarmManager alarmManager = (AlarmManager) getSystemService(ALARM_SERVICE);
                alarmManager.set(AlarmManager.RTC_WAKEUP, calendar.getTimeInMillis(),pendingIntent);
                //alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, calendar.getTimeInMillis(), pendingIntent);

                Intent openMainActivity= new Intent(NewPill_Final.this, MainActivity.class);
                openMainActivity.putExtra("id", id);
                openMainActivity.putExtra("newPill", pill);


                openMainActivity.setFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                startActivityIfNeeded(openMainActivity, 0);


            }
        });

    }

    @Override
    public void onBackPressed() {
        Intent intent = new Intent(NewPill_Final.this, NewPill_TakeWith.class);
        intent.putExtra("newPill", pill);
        intent.putExtras(b);
        startActivity(intent);
    }
}

