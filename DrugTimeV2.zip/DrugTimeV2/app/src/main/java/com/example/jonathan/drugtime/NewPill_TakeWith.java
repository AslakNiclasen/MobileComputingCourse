package com.example.jonathan.drugtime;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class NewPill_TakeWith extends AppCompatActivity {
    private Pill pill;
    private Bundle b;
    private EditText note;


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.newpilltakewith_layout);

        b = getIntent().getExtras();
        pill = b.getParcelable("newPill");

        note = (EditText) findViewById(R.id.the_note);


        Button btBack=(Button)findViewById(R.id.tilforrigeside);
        btBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View V) {
                Intent backIntent = new Intent(NewPill_TakeWith.this, NewPill_ColorCode.class);
                backIntent.putExtra("newPill", pill);
                backIntent.putExtras(b);
                startActivity(backIntent);
            }
        });

        Button btNext=(Button)findViewById(R.id.tilnæsteside);
        btNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View V) {
                String noten = note.getText().toString();
                pill.setNote(noten);
                Intent intent = new Intent(NewPill_TakeWith.this, NewPill_Final.class);
                intent.putExtra("newPill", pill);
                intent.putExtras(b);
                startActivity(intent);

            }
        });




    }




}

