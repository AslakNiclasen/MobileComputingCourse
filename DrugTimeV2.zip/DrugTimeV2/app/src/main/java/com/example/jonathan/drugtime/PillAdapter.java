package com.example.jonathan.drugtime;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

/** class to act as list adapter for rows List */
public class PillAdapter extends ArrayAdapter<Pill> {

    Context context;
    /** To cache views of item */
    private static class ViewHolder {
        private TextView name;
        private TextView quantity;
        private TextView time;
        private ImageView image;
        //private TextView text4;

        /**
         * General constructor
         */
        ViewHolder() {
            // nothing to do here
        }
    }

    /** Inflater for list items */
    private final LayoutInflater inflater;

    public PillAdapter(final Context context, final ArrayList<Pill> objects) {
        super(context, R.layout.activity_listitem, objects);
        this.context = context;
        this.inflater = LayoutInflater.from(context);
    }

    @Override
    public View getView(final int position, View convertView, final ViewGroup parent) {

        //View itemView = convertView;
        ViewHolder holder;
        final Pill pill = getItem(position);

        if(null == convertView) {

            holder = new ViewHolder();

            LayoutInflater inflater = LayoutInflater.from(getContext());
            convertView = inflater.inflate(R.layout.activity_listitem, parent, false);

            holder.name = (TextView)convertView.findViewById(R.id.pillenavn);
            holder.quantity = (TextView)convertView.findViewById(R.id.antal);
            holder.time = (TextView)convertView.findViewById(R.id.tidspunkt);
            holder.image = (ImageView)convertView.findViewById(R.id.billede);

            convertView.setTag(holder);
        } else {
            holder = (ViewHolder)convertView.getTag();
        }

        holder.name.setText(pill.getName());
        holder.name.setTextSize(24f);
        holder.name.setTextColor(Color.parseColor("#000000"));
        holder.quantity.setText(String.valueOf(pill.getQuantity()));
        holder.time.setText(pill.getTime());
        Bitmap billede = pill.getImageBitmap(context, pill.getName(), "someInternalPath");
        holder.image.setImageBitmap(billede);
        //holder.text4.setText(item.getText4());

        return convertView;
    }
}