package com.example.jonathan.drugtime;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.NotificationCompat;
import android.widget.RemoteViews;

import static android.support.v4.app.NotificationCompat.FLAG_INSISTENT;

public class Notification_receiver extends BroadcastReceiver {
    Context context;

    @Override
    public void onReceive(Context context, Intent intent) {
        this.context = context;
        WakeLocker.acquire(context);

        Bundle b = intent.getExtras();
        String name = b.getString("name");
        int id = b.getInt("id");
        int vibrate = b.getInt("vibrate");


        NotificationManager notificationManager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        Intent repeating_intent = new Intent(context, Repeating_activity.class);
        repeating_intent.putExtras(b);

        RemoteViews remoteViews = new RemoteViews(context.getPackageName(), R.layout.customnotification);
        remoteViews.setTextViewText(R.id.title,name);

        PendingIntent pendingIntent = PendingIntent.getActivity(context, id, repeating_intent, PendingIntent.FLAG_UPDATE_CURRENT);

        Uri uri= RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);

        NotificationCompat.Builder builder;
        if (vibrate == 1) {
            builder = new NotificationCompat.Builder(context)
                    .setSmallIcon(android.R.drawable.btn_radio)
                    .setTicker("Pillealarm!")
                    .setContentIntent(pendingIntent)
                    .setContent(remoteViews)
                    .setFullScreenIntent(pendingIntent, true)
                    .setSound(uri)
                    .setVibrate(new long[]{1000, 1000, 1000, 1000, 1000})
                    .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
                    .setAutoCancel(false)
                    .setOngoing(true);
        } else {
            builder = new NotificationCompat.Builder(context)
                    .setSmallIcon(android.R.drawable.btn_radio)
                    .setTicker("Pillealarm!")
                    .setContentIntent(pendingIntent)
                    .setContent(remoteViews)
                    .setAutoCancel(false)
                    .setOngoing(true);
        }

        builder.addExtras(b);

        Notification notification = builder.build();
        notification.flags |= FLAG_INSISTENT;
        notificationManager.notify(id, notification);
    }

}
